##############################################################################
# COPYRIGHT Ericsson 2018
#
# The copyright to the computer program(s) herein is the property of
# Ericsson Inc. The programs may be used and/or copied only with written
# permission from Ericsson Inc. or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the
# program(s) have been supplied.
##############################################################################

from enum import Enum
import os
import subprocess

RSYNC_CMD = "rsync"
RSYNC_ARG = "-azhe ssh"

RsyncOutputSummaryItem = Enum('RsyncOutputSummaryItem', 'total_files, created, deleted, '
                                                        'transferred')


class RsyncManager:
    """
    Class used to encapsulate rsync commands to transfer files over the network.

    It basically sends/receives data from one location to another.
    When sending files from local to remote, it keeps track of whether the file(s) was
    successfully sent or not after a given number of tries.
    """

    def __init__(self, source_path, destination_path, retry=3):
        """
        Initialize Rsync Manager class.

        :param source_path: path of the source file to be transferred.
        :param destination_path: destination location to send the file.
        :param retry: number of tries in case of failure.
        """
        self.source_path = source_path
        self.destination_path = destination_path
        self.retry = retry

    class RsyncOutput:
        """Class used to store relevant output information of rsync commands."""

        def __init__(self, summary_dic):
            """
            Initialize Rsync Output class.

            :param summary_dic: dictionary with data parsed from the rsync output.
            """
            self.n_files = summary_dic[RsyncOutputSummaryItem.total_files.name]
            self.n_created_files = summary_dic[RsyncOutputSummaryItem.created.name]
            self.n_deleted_files = summary_dic[RsyncOutputSummaryItem.deleted.name]
            self.n_transferred_files = summary_dic[RsyncOutputSummaryItem.transferred.name]

        def __str__(self):
            """Representation of stored data in object."""
            return "RsyncOutput:\n" \
                   "Number of files: {}\n" \
                   "Number of created files: {}\n" \
                   "Number of deleted files: {}\n" \
                   "Number of transferred files: {}\n".format(self.n_files,
                                                              self.n_created_files,
                                                              self.n_deleted_files,
                                                              self.n_transferred_files)

    def get_number_of_files_to_send(self):
        """
        Calculate the number of files to be sent in the informed source_path.

        It considers that the path can be either a single file or a folder with other
        files or folders inside.

        If source_path refers to a single file, returns 1, otherwise go through the folder's
        content and count the number of files.

        :return: number of files to be transferred.
        """
        if not os.path.exists(self.source_path):
            raise Exception("Specified path '{}' does not exist".format(self.source_path))

        n_files = 0
        if os.path.isdir(self.source_path):
            for file_name in os.listdir(self.source_path):
                if not os.path.isdir(os.path.join(self.source_path, file_name)):
                    n_files += 1
        else:
            n_files = 1

        if n_files == 0:
            raise Exception("There is no file in '{}' to be copied to the remote location."
                            .format(self.source_path))

        return n_files

    @staticmethod
    def parse_output(output):
        """
        Parse the output of a rsync execution.

        Collect relevant information to be stored in a RsyncOutput object.

        :param output: output after a rsync execution.

        :return: false, if it was not possible to parse the output,
                 RsyncOutput object with the retrieved information.
        """
        lines = str(output).lower().split('\n')

        if len(lines) == 0:
            raise Exception("Empty output.")

        summary_dic = {}
        for summary_item in RsyncOutputSummaryItem:
            summary_dic[summary_item.name] = 0

        for line in lines:
            if "number of" in line:
                par = line.find('(')
                if par != -1:
                    line = line[0:par - 1]

                if line.find(":") == -1:
                    raise Exception("Could not parse rsync output line: {}.".format(line))

                number_of_files = line.split(':')[1].strip()

                key = RsyncOutputSummaryItem.total_files.name

                if RsyncOutputSummaryItem.transferred.name in line:
                    key = RsyncOutputSummaryItem.transferred.name
                elif RsyncOutputSummaryItem.deleted.name in line:
                    key = RsyncOutputSummaryItem.deleted.name
                elif RsyncOutputSummaryItem.created.name in line:
                    key = RsyncOutputSummaryItem.created.name

                summary_dic[key] = number_of_files

        return RsyncManager.RsyncOutput(summary_dic)

    def receive(self):
        """
        Try to receive files from a remote location.

        Remote location is specified by the source_path.
        Destination location is specified by the destination_path.

        An exception is raised if some problem happens during the process.

        :return: RsyncOutput object with the output information of the command.
        """
        try:
            output = subprocess.check_output([RSYNC_CMD, RSYNC_ARG, '--stats', self.source_path,
                                              self.destination_path], stderr=subprocess.PIPE)
            return self.parse_output(output)

        except subprocess.CalledProcessError as cp:
            raise Exception("An error occurred while receiving file: Error code {}"
                            .format(cp.returncode))
        except Exception as e:
            raise Exception("An error occurred while receiving file: {}".format(e.message))

    def send(self):
        """
        Try to send local file(s) referred by source_path to the destination_path location.

        It will try to send the file as many times as specified by the retry variable.

        An exception will be raised if the maximum number of tries is reached without success.
        """
        try:
            n_files = self.get_number_of_files_to_send()

            for current_try in range(1, self.retry + 1):
                output = subprocess.check_output([RSYNC_CMD,
                                                  RSYNC_ARG,
                                                  '--stats',
                                                  self.source_path,
                                                  self.destination_path],
                                                 stderr=subprocess.PIPE)

                rsync_output = self.parse_output(output)

                if not isinstance(rsync_output, RsyncManager.RsyncOutput):
                    raise Exception("Error while parsing the output from rsync command.")

                if int(rsync_output.n_transferred_files) == int(n_files):
                    break

                if current_try == self.retry:
                    raise Exception("Error transferring file(s) to remote server:\n"
                                    "Number of tries: {}\n"
                                    "Number of files to be transferred: {}\n"
                                    "Number of transferred files: {}\n"
                                    .format(self.retry, n_files, rsync_output.n_transferred_files))
        except subprocess.CalledProcessError as cp:
            raise Exception("An error occurred while transferring file: Error code {}"
                            .format(cp.returncode))
        except Exception as e:
            raise Exception("Unknown error occurred while transferring file: {}".format(e.message))


'''
#Sample of usage:

try:
    RsyncManager("local_path", "user@ip:remote_path").copy_to_remote()
except Exception as e:
    print(e)
print("Finished!")
'''
