##############################################################################
# COPYRIGHT Ericsson 2018
#
# The copyright to the computer program(s) herein is the property of
# Ericsson Inc. The programs may be used and/or copied only with written
# permission from Ericsson Inc. or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the
# program(s) have been supplied.
##############################################################################

import multiprocessing as mp
import os

import dill  # nosec
from local_backup_handler import LocalBackupHandler
from logger import CustomLogger
from performance import BackupPerformance
from thread_pool import ThreadPool
from utils import check_offiste_disk_space, check_onsite_disk_space_restore, \
    check_remote_path_exists, create_path, decompress_file, find_elem_dic, get_free_disk_space, \
    get_home_dir, get_onsite_backups_size, popen_communicate, prepare_send_notification_email, \
    remove_path, remove_remote_dir, sufficient_onsite_disk_space, timeit, transfer_file


SCRIPT_FILE = os.path.basename(__file__).split('.')[0]

BKP_TMP_PATH = os.path.join(get_home_dir(), 'bkp_tmp')

MAX_BKP_OFFSITE = 3


def unwrapper_process_backup_list(backup_handler_obj):
    """
    Unwrapper function.

    Reloads a LocalBackupHandler object when using Multiprocessing map function to execute the
    backup of customers in parallel.

    :param backup_handler_obj: LocalBackupHandler object.

    :return: true, when the backup process is finished successfully,
             false, otherwise.
    """
    loaded_backup_handler_object = dill.loads(backup_handler_obj)  # nosec
    if isinstance(loaded_backup_handler_object, LocalBackupHandler):
        return loaded_backup_handler_object.process_backup_list()


class OffsiteBackupHandler:
    """
    Responsible for handling the BUR features.

    Upload or download backup, as well as remote clean up for a set of customers.
    """

    def __init__(self, gpg_manager, offsite_config, enmaas_config_dic,
                 number_threads, number_processors, notification_handler, logger):
        """
        Initialize Offsite Backup Handler object.

        :param gpg_manager: gpg manager object to handle decrypt/encrypt tasks.
        :param offsite_config: information about the remote server.
        :param enmaas_config_dic: information list about customers.
        :param number_threads: number of allowed running threads at a time.
        :param number_processors: number of allowed running process at a time.
        :param notification_handler: notification_handler object to notify via email if some
               error occurs while processing a backup
        :param logger: logger object.
        """
        self.gpg_manager = gpg_manager
        self.offsite_config = offsite_config
        self.enmaas_config_dic = enmaas_config_dic

        self.number_threads = number_threads
        self.number_processors = number_processors

        self.notification_handler = notification_handler

        self.logger = CustomLogger(SCRIPT_FILE, logger.log_full_path, logger.log_level)

    def execute_restore_backup_from_offsite(self, customer_name, backup_tag, backup_destination):
        """
        Execute the restoration of the backup based on the input parameters.

        Check if the desired customer exists before calling the restore function.

        :param customer_name:      customer name to retrieve the backup, empty if all backups
                                   should be retrieved.
        :param backup_tag:         backup tag to be retrieved from the off-site location.
        :param backup_destination: path where the backup will be downloaded.

        :return: tuple (true, success message) if the process occurred successfully,
                 tuple (false, error message) otherwise.
        """
        enmaas_query_config = None
        if customer_name is not None and customer_name != "":
            if customer_name in self.enmaas_config_dic.keys():
                enmaas_query_config = self.enmaas_config_dic.get(customer_name)
            else:
                return False, "Customer not found '{}'.".format(customer_name)

        return self.restore_backup_from_offsite(enmaas_query_config, backup_tag, backup_destination)

    def restore_backup_from_offsite(self, enmaas_config, backup_tag, backup_destination):
        """
        Try to restore a remote backup to the local server.

        The search works as follows:

        1. If only the customer_name is informed, just display all available backups for that
           particular customer.
        2. If only the backup_tag is informed, search for this backup in the off-site by checking
           all customers' data.
            2.1 If no backup with this tag is found, return an error message.
        3. If the backup_tag and the customer_name are informed, try to find the backup in the list
           of that particular customer only.
            3.1 If there is a problem with the customer_name or backup_tag, return an error message.

        :param enmaas_config:      customer object to retrieve the backup, None if all backups
                                   should be retrieved.
        :param backup_tag:         backup tag to be retrieved from the off-site location.
        :param backup_destination: path where the backup will be downloaded.

        :return: tuple (true, success message) if the process occurred successfully,
                 tuple (false, error message) otherwise.
        """
        customer_backup_dic = self.get_offsite_backup_dic(enmaas_config)

        if customer_backup_dic is None:
            return False, "Error while retrieving the list of available backups from off-site"

        if backup_tag is None or not backup_tag.strip():
            return True, "Retrieved list of backups per customer: {}".format(customer_backup_dic)

        customer_name, backup_path_to_be_retrieved = find_elem_dic(customer_backup_dic, backup_tag)

        if not backup_path_to_be_retrieved.strip():
            return False, "Backup tag not found '{}' on off-site.".format(backup_tag)

        if not backup_destination.strip():
            backup_destination = self.enmaas_config_dic[customer_name].backup_path
            self.logger.warning("Backup destination field not informed. Default location used '{}'"
                                .format(backup_destination))
        else:
            backup_destination = os.path.join(backup_destination, customer_name)

        block_size = "MB"
        has_sufficient_space_for_restore, log_message = check_onsite_disk_space_restore(
            backup_path_to_be_retrieved, self.offsite_config.host, backup_destination, block_size)
        if has_sufficient_space_for_restore:
            self.logger.info(log_message)
        else:
            return False, log_message

        if self.download_backup_from_offsite(customer_name,
                                             backup_path_to_be_retrieved,
                                             backup_destination):
            return True, "Backup recovery '{}' to destination '{}' executed successfully." \
                .format(backup_path_to_be_retrieved, backup_destination)

        return False, "Error while restoring backup '{}' to destination '{}'." \
            .format(backup_path_to_be_retrieved, backup_destination)

    def get_offsite_backup_dic(self, enmaas_config=None):
        """
        Query the off-site server looking for the list of available backups.

        If the customer_name is empty, retrieves the available backup from all customers, otherwise
        it gets just the ones from a particular customer.

        :param enmaas_config: customer object whose backup list should be retrieved, None if all
               customers should be searched.

        :return: map containing the list of available backups in the off-site by customer name,
                 None when an error happens.
        """
        offsite_config = self.offsite_config
        logger = self.logger

        remote_root_backup_path = os.path.join(offsite_config.path, offsite_config.folder)

        dir_list_dic = {}
        ssh_get_sorted_dir_list = ""
        if enmaas_config is not None:
            logger.info("Getting list of available backups from customer {}."
                        .format(enmaas_config.name))

            ssh_get_sorted_dir_list = "ls -dt {}/*/\necho END-OF-COMMAND\n" \
                .format(os.path.join(remote_root_backup_path, enmaas_config.name))
            dir_list_dic[enmaas_config.name] = []
        else:
            logger.info("Getting list of available backups from all customers.")
            for enmaas_config in self.enmaas_config_dic.values():
                ssh_get_sorted_dir_list += "ls -dt {}/*/\necho END-OF-COMMAND\n" \
                    .format(os.path.join(remote_root_backup_path, enmaas_config.name))
                dir_list_dic[enmaas_config.name] = []

        stdout, stderr = popen_communicate(offsite_config.host, ssh_get_sorted_dir_list)

        if stderr:
            logger.error("Error to issue the number of backups in the off-site server due to: {}"
                         .format(stderr))
            return None

        dir_list_by_customer = stdout.split('END-OF-COMMAND')
        customer_idx = 0
        for dir_list in dir_list_by_customer:
            if not dir_list.strip():
                continue

            customer_dir_list = []
            for folder_name in dir_list.split('\n'):
                if folder_name != '' and folder_name != '.':
                    customer_dir_path = folder_name.strip()
                    # Removing last slash to avoid errors while handling this path.
                    if customer_dir_path[len(customer_dir_path) - 1] == '/':
                        customer_dir_path = customer_dir_path[0:len(customer_dir_path) - 1]
                    customer_dir_list.append(customer_dir_path)

            key = dir_list_dic.keys()[customer_idx]
            dir_list_dic[key] = customer_dir_list

            customer_idx += 1

        return dir_list_dic

    def download_backup_from_offsite(self, customer_name, backup_path_to_retrieve,
                                     backup_destination):
        """
        Download and restore the backup to the destination directory.

        1. Downloads the informed backup given by restore_backup_path to the destination.
        2. Decompress all volumes and delete the compressed files;
        3. Decrypt all files inside the volumes and delete the decrypted files.

        :param customer_name: customer name whose backup is being downloaded.
        :param backup_path_to_retrieve: backup path on remote location to be downloaded.
        :param backup_destination:      local destination.

        :return: true, if the process occurred successfully,
                 false, otherwise.
        """
        logger = self.logger
        offsite_config = self.offsite_config

        logger.info("Restoring backup '{}' to destination '{}'."
                    .format(backup_path_to_retrieve, backup_destination))

        source_remote_dir = "{}:{}".format(offsite_config.host, backup_path_to_retrieve)

        thread_pool = ThreadPool(self.logger, self.number_threads)

        try:
            backup_folder_name = os.path.basename(backup_path_to_retrieve)
            local_backup_path = os.path.join(backup_destination, backup_folder_name)

            if os.path.exists(local_backup_path):
                logger.warning("A backup with the same tag already exists in this folder '{}'."
                               .format(local_backup_path))
                return False

            if not create_path(backup_destination):
                logger.error("Destination folder could not be created.")
                return False

            logger.info("Downloading backup '{}'.".format(source_remote_dir))

            transfer_file(source_remote_dir, backup_destination)

            logger.info("Processing volumes from backup '{}'.".format(local_backup_path))

            for volume_name in os.listdir(local_backup_path):
                if os.path.isdir(os.path.join(local_backup_path, volume_name)):
                    continue
                thread_pool.create_thread("{}-{}".format(backup_folder_name, volume_name),
                                          self.restore_volume, local_backup_path, volume_name)

            thread_pool.start_pool()

            if not os.path.exists(local_backup_path):
                raise Exception("Backup '{}' was not retrieved to the local system."
                                .format(local_backup_path))

            if not LocalBackupHandler.validate_volumes_metadata(local_backup_path, logger):
                raise Exception("Retrieved backup '{}' could not be validated against metadata."
                                .format(local_backup_path))

        except Exception as e:
            logger.error(e)

            prepare_send_notification_email(self.notification_handler,
                                            customer_name,
                                            backup_path_to_retrieve,
                                            e[0])

            self.clean_local_backup_path(local_backup_path, logger)

            return False

        return True

    @staticmethod
    def clean_local_backup_path(local_backup_path, logger):
        """
        Try to clean local backup path after unsuccessful restoration.

        :param local_backup_path: path to the unsuccessful restored backup.
        :param logger: logger object.
        """
        if os.path.exists(local_backup_path):
            logger.warning("Cleaning unsuccessful restoration path from the local system '{}'"
                           .format(local_backup_path))

            if not remove_path(local_backup_path):
                logger.error("Could not delete unsuccessful restoration path '{}'."
                             .format(local_backup_path))

    def clean_offsite_backup(self):
        """
        Connect to the off-site server and cleans old backups for each customer.

        Keeps most recent backups equivalent to number MAX_BKP_OFFSITE .

        1. Retrieve the list of directories (backups) from each customer.
        2. Check if it is necessary to delete older backups and add the path to a list.
        3. Try to remove the selected backups from the list for all customers.

        :return tuple (true, success message, list of removed directories), if no problem happened
                during the process,
                tuple (false, error message, list of removed directories) otherwise.
        """
        logger = self.logger
        offsite_config = self.offsite_config

        logger.log_info("Performing the clean up on off-site server.")

        dir_list_by_customer_map = self.get_offsite_backup_dic()

        if dir_list_by_customer_map is None:
            return False, "Unable to get the backup map per customer from off-site.", []

        remove_dir_list = []
        for customer in dir_list_by_customer_map.keys():
            number_backup_per_customer = len(dir_list_by_customer_map[customer])
            if number_backup_per_customer > MAX_BKP_OFFSITE:
                logger.info("Off-site location for customer {} has {} backups. "
                            "Removing the {} oldest."
                            .format(customer,
                                    number_backup_per_customer,
                                    number_backup_per_customer - MAX_BKP_OFFSITE))

                # ignore the first MAX_BKP_OFFSITE most recent backups in this list.
                for removable_backup in dir_list_by_customer_map[customer][MAX_BKP_OFFSITE:]:
                    remove_dir_list.append(removable_backup)
            else:
                logger.warning("Customer {} has just {} backup(s) off-site. Nothing to do."
                               .format(customer, number_backup_per_customer))
        ret, output = remove_remote_dir(offsite_config.host, remove_dir_list)

        if not ret:
            return False, "Removal of remote directory failed '{}' due to: {}." \
                .format(remove_dir_list, output), []

        not_removed_list = []
        validated_removed_list = []
        for removed_path in remove_dir_list:
            if not check_remote_path_exists(self.offsite_config.host, removed_path):
                validated_removed_list.append(removed_path)
            else:
                not_removed_list.append(removed_path)

        if len(not_removed_list) != 0:
            log_message = "Following backups were not removed: {}".format(not_removed_list)
            return False, log_message, validated_removed_list

        return True, "Off-site clean up finished successfully.", validated_removed_list

    def restore_volume(self, volume_root_path, volume_name):
        """
        Go through all volumes, decompressing and decrypting the files.

        :param volume_root_path: volume root path.
        :param volume_name:      volume name.
        """
        logger = self.logger

        volume_full_path = os.path.join(volume_root_path, volume_name)

        if not os.path.exists(volume_full_path):
            logger.error("Volume path '{}' does not exist.".format(volume_full_path))
            return

        try:
            logger.info("Decompressing volume '{}'".format(volume_name))

            decompress_file(volume_full_path, volume_root_path, True)

            decompressed_dir = os.path.join(volume_root_path, volume_name.split('.')[0])

            logger.info("Decrypting files from volume '{}'".format(decompressed_dir))

            for encrypted_volume_file in os.listdir(decompressed_dir):
                self.gpg_manager.decrypt_file(os.path.join(decompressed_dir, encrypted_volume_file),
                                              True)

        except Exception as e:
            logger.error(e)
            logger.error("Error while decrypting volume {}.".format(volume_name))

    @timeit
    def execute_backup_to_offsite(self, gen_performance_report=False, cleanup=False, **kwargs):
        """
        Run through all customer's deployments and processes the backup of their volumes.

        Procedure flow is:

        1. Creates a temporary local folder to store the files to be uploaded.
        2. For each deployment do:
            2.1 Validate the remote backup location;
            2.2 Get valid backups to be uploaded;
            2.3 For each valid backup: compress, encrypt and transfer their volumes
                to the remote location.
                2.3.4 Compressed and encrypted data will be placed in a temporary folder
                      before being transferred.
            2.4 If something gets wrong in the process, handle the error and move
                to the next customer.

        3. Deletes the temporary files at the end.

        :param gen_performance_report: flag to whether one should take the performance
                                       report or not.
        :param cleanup:                flag to whether one should do the house keeping of NFS
                                       and off-site server.
        :returns: tuple (true, empty string) when success,
                  tuple (false, error message) otherwise.
        """
        logger = self.logger

        if not create_path(BKP_TMP_PATH):
            log_message = "Temporary folder could not be created."
            return False, log_message

        local_backup_handler_map = {}

        max_required_space_mb = 0
        block_size = "MB"

        for enmaas_conf in self.enmaas_config_dic.values():
            if not os.path.exists(enmaas_conf.backup_path):
                logger.error("Volumes path do not exist '{}' for customer {}"
                             .format(enmaas_conf.backup_path, enmaas_conf.name))
                continue

            temp_customer_root_path = os.path.join(BKP_TMP_PATH, enmaas_conf.name)

            if not create_path(temp_customer_root_path):
                logger.error("Temporary folder could not be created for customer {}."
                             .format(enmaas_conf.name))
                continue

            backup_handler = LocalBackupHandler(self.offsite_config,
                                                enmaas_conf,
                                                temp_customer_root_path,
                                                self.gpg_manager,
                                                self.number_threads,
                                                self.notification_handler,
                                                logger.log_level)

            source_dir = backup_handler.customer_conf.backup_path

            valid_backups_folders = backup_handler.get_local_backup_list()
            valid_value, log_message, backup_size = get_onsite_backups_size(valid_backups_folders,
                                                                            source_dir, block_size)
            if valid_value:
                max_required_space_mb += backup_size
                logger.info(log_message)
            else:
                return False, log_message

            local_backup_handler_map[enmaas_conf.name] = dill.dumps(backup_handler)

        has_sufficient_space_upload, error_message = self.check_disk_space_upload(
            max_required_space_mb, block_size)
        if not has_sufficient_space_upload:
            return False, error_message

        process_pool = mp.Pool(self.number_processors)

        mp_result_map_performance = process_pool.map_async(unwrapper_process_backup_list,
                                                           local_backup_handler_map.values())

        process_pool.close()
        process_pool.join()

        if gen_performance_report:
            backup_performance_obj_list = []
            for backup_performance_list in mp_result_map_performance.get():
                backup_performance_obj_list += backup_performance_list

            BackupPerformance.generate_performance_report(backup_performance_obj_list)

        if not remove_path(BKP_TMP_PATH):
            logger.error("Error while deleting temporary folder '{}' from NFS server"
                         .format(BKP_TMP_PATH))

        if cleanup:
            ret, out_msg, removed_dir = self.clean_offsite_backup()

            if not ret:
                logger.error("Error while performing the clean up off-site due to {}."
                             .format(out_msg))
            else:
                logger.info("{}: Removed directories were: {}".format(out_msg, removed_dir))

        return True, ""

    def check_disk_space_upload(self, max_required_space_mb, block_size):
        """
        Check if there is available space onsite and offsite to upload the backup.

        :param max_required_space_mb: total size of the backups to be run in the current
        job.
        :param block_size: whether MB, GB or TB, used with the log message for better readability.

        :return: tuple (true, empty string) when there is available space;
                 tuple (false, error message), otherwise.
        """
        self.logger.info("The maximum required free disk space to process all valid backups: {} {}".
                         format(max_required_space_mb, block_size))

        valid_value, log_message, free_disk_space_for_tmp_mb = get_free_disk_space(BKP_TMP_PATH)
        if not valid_value:
            return False, log_message

        if not sufficient_onsite_disk_space(free_disk_space_for_tmp_mb, max_required_space_mb):
            log_message = ("Not enough free disk space to store the processed backups "
                           "under: {}, current free space: {} {}, required free space: {} {}"
                           .format(BKP_TMP_PATH, free_disk_space_for_tmp_mb, block_size,
                                   max_required_space_mb, block_size))
            return False, log_message

        self.logger.info("The estimated required free disk space: {} {} to hold the processed "
                         "backups under: {}, is satisfied, available space: {} {}".
                         format(max_required_space_mb, block_size, BKP_TMP_PATH,
                                free_disk_space_for_tmp_mb, block_size))

        sufficient_offsite_disk_space, log_message = \
            check_offiste_disk_space(self.offsite_config.host,
                                     self.offsite_config.full_path,
                                     max_required_space_mb,
                                     block_size)

        if not sufficient_offsite_disk_space:
            return False, log_message

        self.logger.info(log_message)

        return True, ""
