"""
Top-level module for BUR.

This module tracks the version of the package
"""

__version__ = '1.0.0'
