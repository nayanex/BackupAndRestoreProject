##############################################################################
# COPYRIGHT Ericsson 2018
#
# The copyright to the computer program(s) herein is the property of
# Ericsson Inc. The programs may be used and/or copied only with written
# permission from Ericsson Inc. or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the
# program(s) have been supplied.
##############################################################################

import json
import os
import urllib2

from backup.logger import CustomLogger

SCRIPT_FILE = os.path.basename(__file__).split('.')[0]
SEP1 = "-------------------------------------------------------------------------------------------"
SEP2 = "==========================================================================================="


class NotificationHandler:
    """Responsible for handling the BUR notification mails."""

    def __init__(self, email_to, email_url, logger):
        """
        Initialize Notification Handler object.

        :param email_to: where to send notification email.
        :param email_url: which email service to use.
        :param logger: which logger to use.
        """
        self.email_to = email_to
        self.email_url = email_url
        self.logger = CustomLogger(SCRIPT_FILE, logger.log_full_path, logger.log_level)

    def send_mail(self, deployment_name_as_from, subject, message):
        """
        Prepare and sends notification email whenever an error happens during BUR process.

        Reads email service configuration attribute EMAIL_URL

        :param deployment_name_as_from: Deployment's name.
        :param subject: notification email subject.
        :param message: notification email message.
        """
        self.logger.info(SEP2)
        from_sender = "{}@ericsson.com".format(deployment_name_as_from)
        self.logger.info("Sending mail from '%s' to '%s' with subject '%s'.", from_sender,
                         self.email_to, subject)

        json_string = {"personalizations": [{"to": [{"email": self.email_to}], "subject": subject}],
                       "from": {"email": from_sender},
                       "content": [{"type": "text/plain", "value": message}]}
        post_data = json.dumps(json_string).encode("utf8")
        req = urllib2.Request(self.email_url, data=post_data,  # nosec
                              headers={'cache-control': 'no-cache',
                                       'content-type': 'application/json'})
        try:
            response = urllib2.urlopen(req, timeout=10)  # nosec
            if response.code == 200:
                self.logger.info("Sent email to: '%s'.", self.email_to)
            else:
                self.logger.error("Failed to send email to: '%s'. Bad response: '%s' - '%s'",
                                  self.email_to, response.status_code, response)
        except urllib2.URLError as e:
            self.logger.error("Failed to send email to: '%s'. Exception: %s", self.email_to, e)
        finally:
            self.logger.info(SEP2)
