##############################################################################
# COPYRIGHT Ericsson 2018
#
# The copyright to the computer program(s) herein is the property of
# Ericsson Inc. The programs may be used and/or copied only with written
# permission from Ericsson Inc. or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the
# program(s) have been supplied.
##############################################################################

import logging
from logging.handlers import RotatingFileHandler
import sys
import time

OUTPUT_LINE = "===================================================================================="


class CustomLogger(logging.LoggerAdapter):
    """CustomLogger is a customized logger with auxiliary functions to display log messages."""

    def __init__(self, script_name, log_full_path, log_level=logging.DEBUG):
        """
        Initialize log class.

        :param script_name: script name using the logger.
        :param log_full_path: full path to a file to store the log information.
        :param log_level: level in which log messages will be displayed.
        """
        logger = logging.getLogger(script_name)
        super(CustomLogger, self).__init__(logger, {})

        self.log_full_path = log_full_path
        self.log_level = log_level

        if not logger.handlers:
            self.configure_logger()

    def configure_logger(self):
        """Configure logging for this script."""
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

        self.logger.setLevel(self.log_level)

        sh = logging.StreamHandler()
        sh.setLevel(logging.DEBUG)
        sh.setFormatter(formatter)
        self.logger.addHandler(sh)

        if self.log_full_path != "":
            rfh = RotatingFileHandler(self.log_full_path, maxBytes=5 * 1024 * 1024, backupCount=3)
            rfh.setLevel(logging.INFO)
            rfh.setFormatter(formatter)
            self.logger.addHandler(rfh)

    def log_info(self, log_content):
        """
        Log a message between lines to highlight the log.

        :param log_content: content of log message.
        """
        self.info(OUTPUT_LINE)
        self.info(log_content)
        self.info(OUTPUT_LINE)

    def log_error_exit(self, log_content, exit_code):
        """
        Log messages with error level, then exits application with provided exit code.

        :param log_content: content of log message.
        :param exit_code: exit code to exit the application with.
        """
        if not isinstance(log_content, list):
            log_content = [log_content]

        for log_error in log_content:
            self.error(log_error)

        self.error("Exiting (exit code: %s).", exit_code)

        sys.exit(exit_code)

    def log_time(self, msg, elapsed_time):
        """
        Log a message with elapsed time information.

        :param msg:          context message to describe the elapsed time.
        :param elapsed_time: elapsed time to be logged.
        """
        formatted_time = time.strftime('%H:%M:%S', time.gmtime(elapsed_time))

        self.info("%s : %s.", msg, str(formatted_time))
