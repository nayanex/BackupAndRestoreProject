##############################################################################
# COPYRIGHT Ericsson 2018
#
# The copyright to the computer program(s) herein is the property of
# Ericsson Inc. The programs may be used and/or copied only with written
# permission from Ericsson Inc. or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the
# program(s) have been supplied.
##############################################################################

import hashlib
import logging
import os
import pwd
import re
import shutil
import socket
from subprocess import PIPE, Popen
import tarfile
from threading import Timer
import time

from logger import CustomLogger
from rsync_manager import RsyncManager

NUMBER_TRIES = 3
LOGLEVEL = "LogLevel=ERROR"
TIMEOUT = 10

SCRIPT_PATH = os.path.expanduser("~")
LOG_ROOT_PATH = os.path.join(SCRIPT_PATH, "backup", "logs")
USERNAME_PATTERN = re.compile("^(([a-zA-Z]|[a-zA-Z][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*"
                              "([A-Za-z]|[A-Za-z][A-Za-z0-9\-]*[A-Za-z0-9])$")


def create_path(path):
    """
    Create a path in the local storage.

    :param path: path to be created.

    :return: true if path already exists or was successfully created,
             false otherwise.
    """
    if os.path.exists(path):
        return True
    try:
        os.makedirs(path)
    except Exception:
        return False
    return True


def remove_path(path):
    """
    Delete a path from local storage.

    :param path:   file name to be removed.

    :return: true if path does not exist or was successfully deleted,
             false otherwise.
    """
    if not os.path.exists(path):
        return True

    try:
        if os.path.isdir(path):
            shutil.rmtree(path)
        else:
            os.remove(path)
    except Exception:
        return False

    return True


def popen_communicate(host, command):
    """
    Use Popen library to communicate to a remote server by using ssh protocol.

    :param host:    remote host to connect.
    :param command: command to execute on remote server.

    :return: pair stdout, stderr from communicate command,
             empty string pair, otherwise.
    """
    if host == "" or command == "":
        return "", ""

    ssh = Popen(['ssh', '-o', LOGLEVEL, host, 'bash'],
                stdin=PIPE, stdout=PIPE, stderr=PIPE)

    timer = Timer(TIMEOUT, lambda process: process.kill(), [ssh])

    try:
        timer.start()
        stdout, stderr = ssh.communicate(command)
    finally:
        timer.cancel()

    return stdout, stderr


def check_remote_path_exists(host, path):
    """
    Check if a remote path exists.

    :param host:   remote host address, e.g. user@host_ip
    :param path:   remote path to be verified.

    :return: false, if the path does not exist,
             true, otherwise
    """
    ssh_check_dir_command = """
    if [ -d {} ]; then echo "DIR_IS_AVAILABLE"; fi\n
    """.format(path, path)

    stdout, _ = popen_communicate(host, ssh_check_dir_command)

    if stdout.strip() != "DIR_IS_AVAILABLE":
        return False

    return True


def create_remote_dir(host, full_path):
    """
    Try to create a remote directory with ssh commands.

    :param host:      remote host address, e.g. user@host_ip
    :param full_path: full path to be created.

    :return: true, if directory was successfully created
             false, otherwise.
    """
    ssh_create_dir_commands = """
    mkdir {}\n
    echo END-OF-COMMAND\n
    if [ -d {} ]; then echo "DIR_IS_AVAILABLE"; fi\n
    """.format(full_path, full_path)

    stdout, stderr = popen_communicate(host, ssh_create_dir_commands)

    if not stderr:
        split_output = stdout.split("END-OF-COMMAND")

        if len(split_output) < 2 or not split_output[1].strip() == "DIR_IS_AVAILABLE":
            return False
    else:
        return False

    return True


def remove_remote_dir(host, dir_list):
    """
    Remove the informed directory list from the remote server.

    :param host:     remote host address, e.g. user@host_ip
    :param dir_list: directory list.

    :return tuple: true, empty string: if remote directory list was removed successfully,
            tuple: false, error cause: otherwise.
    """
    if host == "" or dir_list == "":
        return False, "Empty entry was provided."

    if isinstance(dir_list, str):
        dir_list = [dir_list]

    if dir_list is []:
        return False, "Empty list was provided."

    remove_dir_cmd = ""

    for d in dir_list:
        folder_path = d.strip()
        remove_dir_cmd += "rm -rf {}\necho END-OF-COMMAND\n".format(folder_path)

    stdout, stderr = popen_communicate(host, remove_dir_cmd)

    if not stderr:
        split_output = stdout.split("END-OF-COMMAND")

        idx = 0
        for cmd_out in split_output:
            if cmd_out.strip() != "":
                return False, cmd_out
            idx += 1
    else:
        return False, stderr

    return True, ""


def find_elem_dic(map_obj, query):
    """
    Find element in a map of arrays.

    :param map_obj: map object.
    :param query:   query string.

    :return:        tuple (key, item) that was found,
                    tuple ("", "") otherwise.
    """
    if not str(query).strip():
        return "", ""

    for key in map_obj.keys():
        for item in map_obj[key]:
            if query in str(item):
                return key, item
    return "", ""


def get_md5(filename):
    """
    Calculate the MD5 code for the specified file path.

    :param filename: file name whose md5 should be calculated.

    :return: md5 code if calculated successfully,
             empty string otherwise.
    """
    if not os.path.exists(filename):
        return ""

    hash_md5 = hashlib.md5()  # nosec
    with open(filename, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


def is_valid_ip(ip):
    """
    Validate if provided IP is valid.

    :param ip: IP in string format to be validated.

    :return: true if ip is valid,
             false, otherwise.
    """
    try:
        socket.inet_aton(ip)
    except socket.error:
        return False

    return True


def validate_host_is_accessible(ip):
    """
    Validate host is accessible.

    :param ip: remote host IP.

    :return: true, if host is accessible,
             false, otherwise.
    """
    with open(os.devnull, "w") as devnull:
        ret_code = Popen(["ping", "-c", "1", ip], stdout=devnull, stderr=devnull).wait()
        return ret_code == 0


def timeit(method):
    """Calculate the elapsed time to execute a function. Decorator function."""
    def timed(*args, **kw):
        ts = time.time()
        result = method(*args, **kw)
        te = time.time()

        if 'get_elapsed_time' in kw:
            if isinstance(kw['get_elapsed_time'], list):
                kw['get_elapsed_time'].append(te - ts)

        return result

    return timed


@timeit
def compress_file(source_path, **kwargs):
    """
    Compress a file or folder using the tar strategy.

    Output file is placed in the same directory where source_path is.

    If an error occurs, an Exception is raised with the details of the problem.

    :param source_path:      file/folder path to be compressed.

    :return true, when the function executed without errors,
            raise an exception otherwise.
    """
    if not os.path.exists(source_path):
        raise Exception("File does not exist '{}'".format(source_path))

    try:
        with tarfile.open("{}.tgz".format(source_path), "w:gz") as tar:
            tar.add(source_path, arcname=os.path.basename(source_path))

    except Exception:
        raise Exception("Error while compressing file '{}'".format(source_path))

    return True


def decompress_file(source_path, output_path, remove_compressed=False):
    """
    Decompress a file using the tar strategy.

    If an error occurs, an Exception is raised with the details of the problem.

    :param source_path:       file to be decompressed.
    :param output_path:       file path of the output file.
    :param remove_compressed: flag to inform if the compressed file should be deleted at the end.

    :return true, when the function executed without errors,
            raise an exception otherwise.
    """
    if not os.path.exists(source_path):
        raise Exception("File does not exist '{}'".format(source_path))

    file_list = []
    if os.path.isdir(source_path):
        for f in os.listdir(source_path):
            file_path = os.path.join(source_path, f)
            file_list.append(file_path)
    else:
        file_list.append(source_path)

    try:
        for f in file_list:
            tar = tarfile.open(f)
            tar.extractall(path=output_path)
            tar.close()

            if remove_compressed:
                remove_path(f)
    except Exception as e:
        raise Exception("Error while decompressing file '{}' due to {}.".format(source_path, e[0]))

    return True


@timeit
def transfer_file(source_path, target_path, **kwargs):
    """
    Transfer a file from the source to a target location by using RsyncManager.

    If the source_path refers to a remote location, the following format is expected:

        e.g. host@ip:/path/to/remote/file

    In this case the receive function will be called, otherwise, the send function is used.

    If an error occurs, an Exception is raised with the details of the problem.

    :param source_path: file name to be transferred or retrieved.
    :param target_path: remote location.

    :return true, when the function executed without errors,
            raise an exception otherwise.
    """
    try:
        if '@' in source_path:
            RsyncManager(source_path, target_path, NUMBER_TRIES).receive()
        else:
            RsyncManager(source_path, target_path, NUMBER_TRIES).send()

    except Exception as e:
        raise Exception("Error while transferring file '{}' due to {}.".format(source_path, e[0]))

    return True


def get_logger(logger_name, log_file_name="", log_level=logging.INFO):
    """
    Create a new logger object with the given parameters.

    :param logger_name:   script name to be added to the logger settings.
    :param log_file_name: log file name.
    :param log_level:     log level.

    :return: a new logger object.
    """
    if logger_name == "":
        return None

    create_path(LOG_ROOT_PATH)

    log_full_path = ""
    if log_file_name != "":
        if not log_file_name.endswith(".log"):
            log_file_name = log_file_name + ".log"
        log_full_path = os.path.join(LOG_ROOT_PATH, log_file_name)

    return CustomLogger(logger_name, log_full_path, log_level)


def get_home_dir():
    """
    Get home directory for the current user.

    :return: home directory.
    """
    return os.path.expanduser("~")


def get_current_user():
    """
    Get current user name.

    :return: current user.
    """
    for name in ('LOGNAME', 'USER', 'LNAME', 'USERNAME'):
        user = os.environ.get(name)
        if user:
            return user
    return pwd.getpwuid(os.getuid())[0]


def get_path_to_docs():
    """
    Get documents directory for the current user.

    :return: documents directory.
    """
    return os.path.join(get_home_dir(), "Documents")


def validate_boolean_input(bool_arg):
    """
    Convert an input value into boolean.

    :param bool_arg: value to be converted into boolean.
    :return: converted value into boolean.
    """
    if isinstance(bool_arg, str):
        return bool_arg.lower() in ("yes", "true", "t", "1")

    return bool_arg


def prepare_send_notification_email(notification_handler, customer_name, backup_path, error_list):
    """
    Prepare a the e-mail notification message including the error list.

    :param notification_handler: notification handler object.
    :param customer_name: customer name.
    :param backup_path: backup path being handled at the moment.
    :param error_list: error list during the process.

    :return: true.
    """
    email_subject = "Error while processing the backup '{}' from customer: {}".format(backup_path,
                                                                                      customer_name)

    email_body = "The following errors happened during this operation:\n"

    if not isinstance(error_list, list):
        error_list = [error_list]

    for error in error_list:
        email_body += error + "\n"

    notification_handler.send_mail(customer_name, email_subject, email_body)

    return True


def get_onsite_backups_size(valid_backups_folders, source_dir, block_size):
    """
    Loop over all valid backups for customer, to calculate the required onsite free disk space.

    :param valid_backups_folders: onsite valid backup folder name.
    :param source_dir: path to onsite valid backup.
    :param block_size: whether MB, GB or TB, used with the log message for better readability.

    :return: tuple: true, informative log message, the valid backup size
             or
             tuple: false, exception message, -1, in case of any failure.
    """
    backup_size = 0
    for backup_folder in valid_backups_folders:
        valid_backup_dir_path = os.path.join(source_dir, backup_folder)

        valid_value, log_message, backup_value = get_backup_size(valid_backup_dir_path)

        if valid_value:
            backup_size += backup_value
        else:
            return False, log_message, -1

    log_message = ("The backup size at path: {},  is: {} {}".format(source_dir,
                                                                    backup_size,
                                                                    block_size))

    return True, log_message, backup_size


def get_backup_size(backup_path):
    """
    Get the backup size on disk.

    :param backup_path: the full backup path on disk.
    :return: tuple: true, empty message to be ignored, the valid backup size.
             or
             tuple: false, exception message, -1, in case of any failure.
    """
    du = Popen(["du", "-sm", backup_path], stdout=PIPE)
    splitline = ""
    for line in du.stdout:
        splitline = line.split()

    log_message = ""
    try:
        backup_size = int(splitline[0])
    except Exception as e:
        log_message = ("Exception while getting backup size, for the path: {}, "
                       "exception message: {}"
                       .format(backup_path, str(e)))
        return False, log_message, -1

    return True, log_message, backup_size


def get_free_disk_space(backup_temp_path):
    """
    Get the free space for the disk where the backup is located.

    :param backup_temp_path: the full backup path on disk.
    :return: tuple: true, empty message to be ignored, the valid backup size.
             or
             tuple: false, exception message, -1, in case of any failure.
    """
    df = Popen(["df", "-k", backup_temp_path], stdout=PIPE)
    for line in df.stdout:
        splitline = line.split()

    mounted_on = ""
    log_message = ""
    try:
        free_disk_space = int(splitline[3])
        free_disk_space_mb = free_disk_space / 1000  # block size in MB
        mounted_on = str(splitline[5])
    except Exception as e:
        log_message = ("Exception while getting free disk space, where the path: {},"
                       " is mounted on: {}, exception message: {}."
                       .format(backup_temp_path, mounted_on, str(e)))
        return False, log_message, -1

    return True, log_message, free_disk_space_mb


def sufficient_onsite_disk_space(free_disk_space_for_tmp_mb, max_required_space_mb):
    """
    Check whether the disk has sufficient free space to temporarily hold the processed backups.

    :param free_disk_space_for_tmp_mb: the free disk space to check.
    :param max_required_space_mb: the required disk space to processed to backup processing.
    :return: True if the disk has sufficient free space, False otherwise.
    """
    if free_disk_space_for_tmp_mb <= max_required_space_mb:
        return False
    return True


def check_offiste_disk_space(host, backup_path_at_offsite, max_required_space_mb, block_size):
    """
    Check whether the disk on offsite has sufficient free disk space to store the backups.

    :param host: offsite machine to connect to, OFFSITE_USERNAME@OFFISTE_IP.
    :param backup_path_at_offsite: full backup path at offsite.
    :param max_required_space_mb: the required space at offsite.
    :param block_size: whether MB, GB or TB, used with the log message for better readability.
    :return: tuple: true, informative message if there's enough disk space offsite.
             or
             tuple: false, error message if there's no enough disk space offsite.
             or
             tuple: false, exception message, in case of any failure.
    """
    command = "df -k " + backup_path_at_offsite

    stdout, stderr = popen_communicate(host, command)

    try:
        std_output_list = stdout.split('\n')
        if std_output_list is None or len(std_output_list) <= 0:
            log_message = ("Invalid output from offsite while checking disk space for path: {}"
                           .format(backup_path_at_offsite))
            return False, log_message

        file_system_disk_summary = str(std_output_list[1])
        file_summary_values = file_system_disk_summary.split()

        offsite_free_disk_space = int(file_summary_values[3])
        offsite_free_disk_space_mb = offsite_free_disk_space / 1000  # block size in MB

        if offsite_free_disk_space_mb <= max_required_space_mb:
            log_message = "Insufficient disk space at offsite for the path: {}, " \
                          "available disk space: {} {}, required disk space {} {}" \
                .format(backup_path_at_offsite, offsite_free_disk_space_mb, block_size,
                        max_required_space_mb, block_size)
            return False, log_message

    except Exception as e:
        log_message = ("Exception while getting free disk space on offsite, for the path: {} "
                       "exception message: {}."
                       .format(backup_path_at_offsite, str(e)))
        return False, log_message

    log_message = ("The estimated required free disk space on offsite for the path: {}, "
                   "is satisfied, the required space: {} {}, the available space: {} {}"
                   .format(backup_path_at_offsite, max_required_space_mb, block_size,
                           offsite_free_disk_space_mb, block_size))
    return True, log_message


def check_onsite_disk_space_restore(backup_path_offiste, host, bkp_restore_path, block_size):
    """
    Check whether the disk onsite has enough free space, to download the backup from offsite.

    :param backup_path_offiste: backup path to be restored from offsite.
    :param host: offsite machine to connect to, OFFSITE_USERNAME@OFFISTE_IP.
    :param bkp_restore_path: the destination path where the downloaded backup will be stored.
    :param block_size: whether MB, GB or TB, used with the log message for better readability.
    :return: tuple: true, informative message if there's enough disk space to restore the backup.
             or
             tuple: false, message if there's no enough disk space onsite to restore the backup.
             or
             tuple: false, exception message, in case of any failure.
    """
    valid, bkp_restore_path, log_msg = get_active_part_bkp_restore_destination(bkp_restore_path)
    if not valid:
        return False, log_msg

    valid, error_message, free_disk_space_onsite_mb = get_free_disk_space(bkp_restore_path)
    if not valid:
        return False, error_message

    valid, error_message, bkp_size_offsite_mb = get_offsite_backup_size(backup_path_offiste, host)
    if not valid:
        return False, error_message

    has_enough_space_to_restore = sufficient_onsite_disk_space_restore(bkp_size_offsite_mb,
                                                                       free_disk_space_onsite_mb)

    if has_enough_space_to_restore:
        log_msg = "The backup restore destination: {} has enough disk space: {} {}, " \
                  "to restore the backup: {} with size: {} {}."\
            .format(bkp_restore_path, free_disk_space_onsite_mb, block_size,
                    backup_path_offiste, bkp_size_offsite_mb, block_size)
        return True, log_msg
    else:
        log_msg = "The backup restore destination: {} doesn't have enough disk space " \
                  "to restore the backup: {} from offsite, " \
                  "the least required disk space: {} {}, " \
                  "but the available disk space: {} {}." \
            .format(bkp_restore_path, backup_path_offiste, bkp_size_offsite_mb, block_size,
                    free_disk_space_onsite_mb, block_size)
        return False, log_msg


def get_active_part_bkp_restore_destination(backup_destination):
    """
    Get the physical backup restore destination path, to perform disk space check on it.

    :param backup_destination: the provided backup restore destination path as input from console.
    :return: tuple: true, restore backup destination after shrinking, informative message,
             if the restore backup destination path or path head at least, exist.
             or
             tuple: false, if neither the restore backup destination path nor the path head exist.
    """
    starts_with_dot = str(backup_destination)[0] == '.'
    absolute_path = os.path.isabs(backup_destination)
    if not starts_with_dot and not absolute_path:
        log_message = "The provided backup restore destination: {} is not a valid path, " \
                      "the path should start with '.' or '/' ."\
            .format(backup_destination)
        return False, backup_destination, log_message

    original_bkp_destination = backup_destination
    while not path_exist(backup_destination):
        if backup_destination.strip():
            backup_destination = shrink_bkp_destination(backup_destination)
        else:
            log_message = "No part of the backup destination path: {} exists."\
                .format(original_bkp_destination)
            return False, backup_destination, log_message

    log_message = "The backup destination to check after shrinking: " + backup_destination
    return True, backup_destination, log_message


def path_exist(path):
    """
    Check if a given path exist.

    :param path: the path to check.
    :return: true, if the path exists, false otherwise.
    """
    if os.path.exists(path):
        return True
    else:
        return False


def shrink_bkp_destination(backup_destination):
    """
    Shrink the provided backup restore destination path, in order to check the free disk space.

    :param backup_destination: the provided backup restore destination path as input from console.
    :return: backup restore destination path after shrinking.
    """
    bkp_dest_head, bkp_dest_tail = os.path.split(backup_destination)
    return bkp_dest_head


def get_offsite_backup_size(bkp_path_offsite, host):
    """
    Get the backup size from offsite, provided the path on offsite.

    This method can only be executed on offsite VM with a linux OS, not solaris(because of -b).
    Otherwise it will fail and stop the restore process.

    :param bkp_path_offsite: the full backup path on offsite disk.
    :param host: offsite machine to connect to, OFFSITE_USERNAME@OFFISTE_IP.
    :return: tuple: true, empty message to be ignored, the valid backup size.
             or
             tuple: false, exception message, -1, in case of any failure.
    """
    command = "du -bms " + bkp_path_offsite
    stdout, stderr = popen_communicate(host, command)

    std_output_list = stdout.split('\t')
    if std_output_list is None or len(std_output_list) <= 0:
        log_message = ("Invalid output from offsite while getting backup size for path: {}"
                       .format(bkp_path_offsite))
        return False, log_message

    log_message = ""
    try:
        backup_size = int(std_output_list[0])
    except Exception as e:
        log_message = ("Exception while getting backup size from offsite, for the path: {}, "
                       "exception message: {}"
                       .format(bkp_path_offsite, str(e)))
        return False, log_message, -1

    return True, log_message, backup_size


def sufficient_onsite_disk_space_restore(bkp_size_offsite_mb, free_disk_space_onsite_mb):
    """
    Check whether the disk onsite has sufficient free space to download the backup from offsite.

    :param bkp_size_offsite_mb: the required disk space to download and process the backup.
    :param free_disk_space_onsite_mb: the free disk space to check against.
    :return: True if the disk has sufficient free space, False otherwise.
    """
    if free_disk_space_onsite_mb <= bkp_size_offsite_mb:
        return False
    return True


def is_host_username_valid(username):
    """
    Validate if host username is valid.

    :param username: the username.
    :return: True if it is valid, otherwise, returns False.
    """
    is_valid_username = re.match(USERNAME_PATTERN, username)
    if not username:
        return True
    if is_valid_username is None:
        return False
    return True


def is_valid_host(host):
    """
    Validate if host is valid.

    :param host: host ip
    :return: True if host is valid, returns False otherwise
    """
    ip_address = re.split('@', host)[-1]
    username = host.split('@')[0]

    if '@' in host:
        if is_host_username_valid(username) and is_valid_ip(ip_address):
            return True
    elif is_valid_ip(ip_address) or host == 'localhost':
        return True
    return False
