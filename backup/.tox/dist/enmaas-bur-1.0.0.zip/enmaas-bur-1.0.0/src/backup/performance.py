##############################################################################
# COPYRIGHT Ericsson 2018
#
# The copyright to the computer program(s) herein is the property of
# Ericsson Inc. The programs may be used and/or copied only with written
# permission from Ericsson Inc. or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the
# program(s) have been supplied.
##############################################################################

from enum import Enum
import os

SCRIPT_PATH = os.path.dirname(__file__)
PERFORMANCE_FILE = os.path.join(SCRIPT_PATH, 'performance.csv')

VolumeReportKeys = Enum('VolumeReportKeys', 'performance_data, output, exit_code')
TimeConstants = Enum('TimeConstants', 'COMPRESS_TIME, ENCRYPT_TIME, TRANSFER_TIME, TOTAL_TIME')


class BackupPerformance:
    """
    Class to store information about the performance of the backup process.

    It also provides functions to calculate and generate a csv report.
    """

    def __init__(self, name, volume_report_dic, transfer_time, n_threads):
        """
        Initialize Backup Performance class.

        :param name: customer name.
        :param volume_report_dic: volume report.
        :param transfer_time: transfer time.
        :param n_threads: number of active threads.
        """
        self.name = name
        self.process_times = self.calculate_performance(volume_report_dic, transfer_time, n_threads)

    def __str__(self):
        """
        To string method.

        :return: string with the string representation of the class.
        """
        return "%s, " % self.name + \
               " %.2f, " % self.process_times[TimeConstants.COMPRESS_TIME.value - 1] + \
               " %.2f, " % self.process_times[TimeConstants.ENCRYPT_TIME.value - 1] + \
               " %.2f, " % self.process_times[TimeConstants.TRANSFER_TIME.value - 1] + \
               " %.2f\n" % self.process_times[TimeConstants.TOTAL_TIME.value - 1]

    @staticmethod
    def generate_performance_report(backup_report_data):
        """
        Generate a report with the collected elapsed times from each backup.

        The report contains the following data:

        1. Time to compress.
        2. Time to encrypt.
        3. Time to transfer to the off-site.

        :param backup_report_data: array of BackupPerformance objects.
        """
        if not os.path.exists(PERFORMANCE_FILE):
            f = open(PERFORMANCE_FILE, 'a')
            f.write(str(BackupPerformance.get_header()))
            f.close()

        with open(PERFORMANCE_FILE, 'a') as report_file:
            for performance_item in backup_report_data:
                report_file.write(str(performance_item))

    @staticmethod
    def calculate_performance(volume_report, transfer_time, n_threads):
        """
        Calculate the elapsed time to process a single backup.

        :param volume_report: time results (compress and encrypt times).
        :param transfer_time: transfer time.
        :param n_threads:     number of active threads used to process this backup.

        :return: array with elapsed times (compress, encrypt, transfer and total times).
        """
        process_time = [0.0, 0.0, 0.0, 0.0]

        for key in volume_report.keys():
            performance_time = volume_report[key][VolumeReportKeys.performance_data.name]

            process_time[TimeConstants.ENCRYPT_TIME.value - 1] += \
                performance_time[TimeConstants.ENCRYPT_TIME.value - 1] / n_threads
            process_time[TimeConstants.COMPRESS_TIME.value - 1] += \
                performance_time[TimeConstants.COMPRESS_TIME.value - 1] / n_threads

        process_time[TimeConstants.TRANSFER_TIME.value - 1] = transfer_time

        idx = 0
        for elapsed_time in process_time:
            if idx != TimeConstants.TOTAL_TIME.value - 1:
                process_time[TimeConstants.TOTAL_TIME.value - 1] += elapsed_time
            idx += 1

        return process_time

    @staticmethod
    def get_header():
        """
        Return the header of the performance report.

        :return: header.
        """
        return "NAME, COMPRESS_TIME, ENCRYPT_TIME, TRANSFER_TIME, TOTAL_TIME\n"
