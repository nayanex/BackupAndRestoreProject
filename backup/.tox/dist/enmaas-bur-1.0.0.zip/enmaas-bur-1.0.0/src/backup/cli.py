"""Module allowing for ``python -m bur <arguments>``."""

import main as application


def main():
    """Execute the main bit of the application."""
    application.main()
