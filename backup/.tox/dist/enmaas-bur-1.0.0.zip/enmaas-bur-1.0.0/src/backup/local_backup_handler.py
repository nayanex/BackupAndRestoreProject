##############################################################################
# COPYRIGHT Ericsson 2018
#
# The copyright to the computer program(s) herein is the property of
# Ericsson Inc. The programs may be used and/or copied only with written
# permission from Ericsson Inc. or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the
# program(s) have been supplied.
##############################################################################

from enum import Enum
import glob
import json
import logging
import os


from performance import BackupPerformance, TimeConstants, VolumeReportKeys
from thread_pool import ThreadPool
from utils import check_remote_path_exists, compress_file, create_path, create_remote_dir, \
    get_logger, prepare_send_notification_email, remove_path, transfer_file

SCRIPT_FILE = os.path.basename(__file__).split('.')[0]

SUCCESS_FLAG_FILE = "BACKUP_OK"
METADATA_FILE_SUFFIX = "_metadata"
MetadataKeys = Enum('MetadataKeys', 'objects, md5')

MIN_BKP_LOCAL = 1


class LocalBackupHandler:
    """
    Class responsible for executing the backup upload feature for a customer.

    This task is optimized by multi-threading to handle each volume for each backup.

    After the backup is complete, a clean up function might be called to perform housekeeping on
    the local server.
    """

    def __init__(self, offsite_config, customer_conf, temp_customer_root_path,
                 gpg_manager, number_threads, notification_handler, log_level=logging.INFO):
        """
        Initialize Local Backup Handler object.

        Creates logger for this instance.

        :param offsite_config: details of the offsite server.
        :param customer_conf: details of the local customer server.
        :param temp_customer_root_path: temporary path to store files during the backup.
        :param gpg_manager: gpg manager object to handle encryption and decryption.
        :param number_threads: maximum number of running threads at a time.
        :param log_level: level of logging to be used.
        """
        self.customer_conf = customer_conf
        self.offsite_config = offsite_config
        self.temp_customer_root_path = temp_customer_root_path

        self.logger = get_logger("{}-{}".format(SCRIPT_FILE, customer_conf.name),
                                 customer_conf.name, log_level)
        self.gpg_manager = gpg_manager
        self.gpg_manager.logger = self.logger
        self.number_threads = number_threads

        self.notification_handler = notification_handler

    def process_backup_list(self):
        """
        Retrieve and process a list of valid backups.

        Processing includes - compression, encryption and uploading tasks.

        Errors raised by the called methods are handled by this method.

        :return a list of BackupPerformance objects with the elapsed times for each backup.
        """
        logger = self.logger
        offsite_config = self.offsite_config
        backup_list = self.get_local_backup_list()

        if backup_list is None or len(backup_list) == 0:
            logger.info("There isn't a valid backup for the customer %s.", self.customer_conf.name)
            return False

        logger.log_info("Doing backup of: {}, directories: {}"
                        .format(self.customer_conf.name, backup_list))

        remote_root_path = os.path.join(offsite_config.full_path, self.customer_conf.name)

        if not check_remote_path_exists(offsite_config.host, remote_root_path):
            if not create_remote_dir(offsite_config.host, remote_root_path):
                error_message = "Remote directory could not be created '{}' for customer {}".\
                    format(remote_root_path, self.customer_conf.name)
                logger.error(error_message)
                return False

        backup_performance_list = []
        for current_backup_dir in backup_list:
            logger.log_info("Process_id: {}, processing directory: {}, for: {}"
                            .format(os.getpid(), current_backup_dir, self.customer_conf.name))

            remote_current_backup_path = os.path.join(remote_root_path, current_backup_dir)

            if check_remote_path_exists(offsite_config.host, remote_current_backup_path):
                logger.info("Customer {} has a backup with the same name {}. Nothing to do."
                            .format(self.customer_conf.name, current_backup_dir))
                continue

            local_current_backup_path = os.path.join(self.customer_conf.backup_path,
                                                     current_backup_dir)

            tmp_path = os.path.join(self.temp_customer_root_path, current_backup_dir)

            try:
                single_backup_performance = self.process_volume_list(local_current_backup_path,
                                                                     tmp_path,
                                                                     remote_root_path)

                backup_performance_list.append(single_backup_performance)
            except Exception as e:
                logger.error(e[0])

        return backup_performance_list

    def process_volume_list(self, source_dir, tmp_customer_backup_path, remote_dir):
        """
        Compress, encrypt and transfer all volumes to the off-site server.

        If an error occurs, an Exception is raised with the details of the problem.

        Notification e-mails are sent in case of failure when processing the volumes or problem
        when transferring the backup to the off-site.

        :param source_dir:               backup directory with the volumes to be processed.
        :param tmp_customer_backup_path: path in which the compressed/encrypted volumes will
                                         be placed temporarily.
        :param remote_dir:               target remote path where the backup will be transferred.

        :return: BackupPerformance object with the times to process the compression,
                 encryption and transfer.
        """
        if not create_path(tmp_customer_backup_path):
            raise Exception("Temporary folder '{}' could not be create for customer {}."
                            .format(tmp_customer_backup_path, self.customer_conf.name))

        thread_pool = ThreadPool(self.logger, self.number_threads)

        volume_report = {}

        for volume_folder in os.listdir(source_dir):

            volume_path = os.path.join(source_dir, volume_folder)
            if os.path.isfile(volume_path):
                continue

            volume_report[volume_folder] = {}

            thread_pool.create_thread("{}-{}".format(self.customer_conf.name, volume_folder),
                                      self.process_volume,
                                      volume_path,
                                      os.path.join(tmp_customer_backup_path, volume_folder),
                                      volume_report[volume_folder])

        thread_pool.start_pool()

        if not self.validate_processed_volumes(source_dir, volume_report):
            raise Exception("Failed to process backup '{}' from customer {}.".format(
                source_dir, self.customer_conf.name))

        try:
            transfer_time = self.transfer_backup_to_offsite(tmp_customer_backup_path, remote_dir)
        except Exception as e:
            prepare_send_notification_email(self.notification_handler,
                                            self.customer_conf.name,
                                            source_dir,
                                            e[0])
            raise Exception(e[0])

        return BackupPerformance(self.customer_conf.name, volume_report,
                                 transfer_time, thread_pool.max_threads)

    def validate_processed_volumes(self, backup_source_dir, volume_report):
        """
        Validate the processed volumes of a single backup.

        The validation is done by getting all the returned error messages for that volume.

        Send a notification e-mail in case of error.

        :param backup_source_dir: backup local source directory.
        :param volume_report: dictionary with the results of processing the volumes for a
        particular backup.

        :return: true, if no error happened;
                 false otherwise.
        """
        failed_volume_error_message_list = []

        for key in volume_report.keys():
            if not volume_report[key][VolumeReportKeys.exit_code.name]:
                error_message = volume_report[key][VolumeReportKeys.output.name]
                failed_volume_error_message_list.append(error_message)
                self.logger.error(error_message)

        if len(failed_volume_error_message_list) > 0:
            prepare_send_notification_email(self.notification_handler,
                                            self.customer_conf.name,
                                            backup_source_dir,
                                            failed_volume_error_message_list)
            return False

        return True

    def process_volume(self, volume_path, tmp_volume_path, volume_report=None):
        """
        Process a single volume folder.

        fulfills the volume report dictionary with the results of the operation.

        Processing includes encrypting each file and compressing the folder in the end.

        :param volume_path:     path of the volume.
        :param tmp_volume_path: local temporary path to store auxiliary files.

        :param volume_report:   map to store the result of processing this volume
                                (performance_data and exit_code keys).
        """
        logger = self.logger

        if volume_report is not None:
            volume_report[VolumeReportKeys.performance_data.name] = [0.0, 0.0]
            volume_report[VolumeReportKeys.output.name] = ""
            volume_report[VolumeReportKeys.exit_code.name] = False

        try:
            if not create_path(tmp_volume_path):
                raise Exception("Temporary folder could not be created for customer {}."
                                .format(self.customer_conf.name))

            process_time = [0.0, 0.0]

            for volume_file in os.listdir(volume_path):
                source_file_path = os.path.join(volume_path, volume_file)
                encrypt_elapsed_time = []
                self.gpg_manager.encrypt_file(source_file_path, tmp_volume_path,
                                              get_elapsed_time=encrypt_elapsed_time)
                logger.log_time("Elapsed time to encrypt file '{}'".format(tmp_volume_path),
                                encrypt_elapsed_time[0])
                process_time[TimeConstants.ENCRYPT_TIME.value - 1] += encrypt_elapsed_time[0]

            logger.info("Compressing volume '{}' for customer {}."
                        .format(tmp_volume_path, self.customer_conf.name))

            compress_time = []
            compress_file(tmp_volume_path, get_elapsed_time=compress_time)
            logger.log_time("Elapsed time to compress volume '{}'"
                            .format(tmp_volume_path), compress_time[0])
            process_time[TimeConstants.COMPRESS_TIME.value - 1] = compress_time[0]

            if not remove_path(tmp_volume_path):
                raise Exception("Error while deleting temporary path '{}' from customer {}."
                                .format(tmp_volume_path, self.customer_conf.name))

            if volume_report is not None:
                volume_report[VolumeReportKeys.performance_data.name] = process_time
                volume_report[VolumeReportKeys.exit_code.name] = True

        except Exception as e:
            volume_report[VolumeReportKeys.output.name] = \
                "Error while processing volume {} from customer {} due to: {}.".format(
                    volume_path, self.customer_conf.name, e[0])

    def transfer_backup_to_offsite(self, tmp_customer_backup_path, remote_dir):
        """
        Transfer a backup already compressed and encrypted to the offsite.

        :param tmp_customer_backup_path: temporary folder where the backup volumes are stored.
        :param remote_dir:               remote location to send the backup.

        :return: elapsed time to transfer the backup.
        """
        offsite_config = self.offsite_config
        logger = self.logger

        try:
            target_dir = "{}:{}".format(offsite_config.host, remote_dir)

            logger.info("Transferring file '{}' to '{}'".format(tmp_customer_backup_path,
                                                                target_dir))

            transfer_time = []
            transfer_file(tmp_customer_backup_path, target_dir, get_elapsed_time=transfer_time)
            logger.log_time("Elapsed time to transfer file '{}'"
                            .format(tmp_customer_backup_path), transfer_time[0])

        except Exception as e:
            backup_name = os.path.basename(tmp_customer_backup_path)

            raise Exception("Error while transferring backup {} from customer {} to offsite. Due "
                            "to {}."
                            .format(backup_name, self.customer_conf.name, e[0]))
        finally:
            if not remove_path(tmp_customer_backup_path):
                raise Exception("Error to delete temporary path '{}' from customer {}."
                                .format(tmp_customer_backup_path, self.customer_conf.name))

        return transfer_time[0]

    def clean_local_backup(self, customer_backup_path):
        """
        Clean the local customer's folder, keeping at least MAX_BKP_NFS stored.

        :param customer_backup_path:  path to the customer's backup folder in NFS.

        :return tuple (true, message) if no error happened,
                tuple (false, message), otherwise.
        """
        logger = self.logger
        logger.log_info("Performing the clean up on NFS path '{}'."
                        .format(self.customer_conf.backup_path))

        number_backup_dir = 0
        for backup_dir in os.listdir(os.path.normpath(self.customer_conf.backup_path)):
            if os.path.isfile(os.path.join(self.customer_conf.backup_path, backup_dir)):
                continue
            number_backup_dir += 1

        logger.info("There are currently {} backups in the folder '{}'."
                    .format(number_backup_dir, self.customer_conf.backup_path))

        if number_backup_dir > MIN_BKP_LOCAL:
            logger.info("Removing backup '{}' from NFS server.".format(customer_backup_path))

            if not remove_path(customer_backup_path):
                return False, "Error while deleting folder '{}' from NFS server." \
                    .format(customer_backup_path)
        else:
            return True, "Backup NOT removed '{}'. Just {} backup found." \
                .format(customer_backup_path, MIN_BKP_LOCAL)

        return True, "Backup removed successfully '{}'.".format(customer_backup_path)

    def get_local_backup_list(self):
        """
        Return a list of recent backup folders after validation against success flag.

        Do not return the most recent valid backup when there are more than
        MIN_BKP_LOCAL in the system.

        :return: a list of backup folders to be uploaded, when it exists,
                 None when an error happens.
        """
        logger = self.logger
        source_dir = self.customer_conf.backup_path

        if not os.path.exists(source_dir):
            logger.error("Invalid backup source path '{}'.".format(source_dir))
            return None

        logger.info("Getting the list of valid backups from '{}'.".format(source_dir))

        folder_list = []
        for folder_name in os.listdir(source_dir):
            if os.path.isfile(os.path.join(source_dir, folder_name)):
                continue
            folder_list.append(folder_name)

        if len(folder_list) == 0:
            return []

        valid_dir_list = []
        for backup_folder in folder_list:
            backup_path = os.path.join(source_dir, backup_folder)

            if not os.path.exists(os.path.join(backup_path, SUCCESS_FLAG_FILE)):
                logger.warning("Backup '{}' does not have a success flag. Skipping this one."
                               .format(backup_path))
                continue

            valid_dir_list.append(backup_folder)

        valid_dir_list.sort(key=lambda s: os.path.getmtime(os.path.join(source_dir, s)),
                            reverse=True)
        if len(valid_dir_list) > MIN_BKP_LOCAL:
            del valid_dir_list[0]

        return valid_dir_list

    @staticmethod
    def validate_volumes_metadata(backup_path, logger):
        """
        Go through the volume list and validate its content against metadata file.

        :param backup_path: backup path.
        :param logger:      logger object.

        :return: true, if the backup was correctly validated,
                 false, otherwise.
        """
        logger.info("Validating backup '{}' against its volumes' metadata.".format(backup_path))

        for volume_folder in os.listdir(backup_path):
            volume_path = os.path.join(backup_path, volume_folder)

            if not os.path.isdir(volume_path):
                continue

            metadata_file = glob.glob(os.path.join(volume_path, str('*' + METADATA_FILE_SUFFIX)))
            if len(metadata_file) != 1 \
                    or not LocalBackupHandler.validate_root_path(volume_path,
                                                                 logger) \
                    or not LocalBackupHandler.validate_metadata(volume_path,
                                                                metadata_file[0],
                                                                logger):
                logger.error("Backup '{}' could not be validated. Checking the next one."
                             .format(backup_path))
                return False

        return True

    @staticmethod
    def validate_root_path(root_path, logger):
        """
        Validate the root path of a specific volume.

        :param root_path:          volume root path for a specific deployment.
        :param logger:             logger object.

        :return: true, if root path exists and is a directory;
                 false otherwise.
        """
        logger.info("Validating root_path '{}'.".format(root_path))
        if not os.path.exists(root_path):
            logger.error("Metadata error: Root path '{}' does not exist.".format(root_path))
            return False

        if not os.path.isdir(root_path):
            logger.error("Metadata error: Root path '{}' is not a folder.".format(root_path))
            return False

        return True

    @staticmethod
    def validate_metadata(root_path, metadata_file_name, logger):
        """
        Validate the metadata file from a specific volume against the system.

        :param root_path:          volume root path for a specific deployment.
        :param metadata_file_name: metadata file name.
        :param logger:             logger object.

        :return: true, if all files specified in the metadata are found and have the same md5 code;
                 false otherwise.
        """
        logger.info("Validating metadata file {}.".format(metadata_file_name))

        if not os.path.exists(metadata_file_name):
            logger.error("Metadata error: File '{}' does not exist.".format(metadata_file_name))
            return False

        try:
            with open(metadata_file_name) as metadata_file:
                metadata_json = json.load(metadata_file)
        except Exception as e:
            logger.error(e)
            logger.error("Metadata error: Could not parse metadata file '{}'."
                         .format(metadata_file_name))
            return False

        file_list = metadata_json[MetadataKeys.objects.name]

        file_list_size = len(file_list)
        file_list_system = len(os.listdir(root_path))

        # Ignore _metadata and _sha256file files.
        if file_list_size != file_list_system - 2:
            logger.error("Metatada error: Invalid number of files (informed {}, found {})."
                         .format(file_list_size, file_list_system))
            return False

        for file_dic in file_list:

            if len(file_dic.keys()) != 1:
                logger.error("Metatada error: File entry is malformed.")
                return False

            metadata_file_path = file_dic.keys()[0]
            system_file_path = os.path.join(root_path, metadata_file_path)

            if not os.path.exists(system_file_path):
                logger.error("Metatada error: File '{}' does not exist in the system."
                             .format(system_file_path))
                return False

            if MetadataKeys.md5.name not in file_dic[metadata_file_path].keys():
                logger.error("Metatada error: Missing key {} for file {}."
                             .format(MetadataKeys.md5.name, metadata_file_path))
                return False

        return True
